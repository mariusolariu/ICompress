#include <iostream>
using std :: cout;
using std :: endl;

/*
// order using references
void order(int& a, int& b){
	int tmp;

	if (a  > b){
		tmp = a;
	    a = b;
		b = tmp;
	}

}
*/


void order(int* a, int* b){

	if (*a  > *b){
		*a ^= *b;
	    *b ^= *a;
		*a ^= *b;
	}
}
//arrays are passed "by pointer"
void sort(int len, int *myArray){
    int i, j;

		//bubblesort
		for (i = 0; i < len - 1; i++){
			for (j = 0; j < len - 1 - i; j++){
				
		   		//order ( myArray[j], myArray[j + 1]);
				order ( myArray + j, myArray + j + 1 );
			}
		}

}

int main(){
		int myArray[] = {3, -2, 4, 100, -15, 22, 34, 0, -22, 10};
		int length = sizeof(myArray) / sizeof(int);
		
		sort( length , myArray);

		cout << "The sorted array:" << endl;
		int t;

		for (t = 0; t < length; t++){
		   cout << "myArray[" << t << "]=" << myArray[t] << endl;
		}


	return 0;
}
