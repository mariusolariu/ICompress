#include <iostream>
#include <string.h>

using std :: cout;
using std :: endl;


void order(const char*& a, const char*& b){
	const char *tmp;

   // we can't compare the pointer values because they represent hex numbers and not the strings that we are interested in
	if (strcmp(a , b) > 0 ) {	
		tmp = a;
        a = b;
		b = tmp;
	}

}

//arrays are passed "by pointer"
void sort(int len, const char* myStringsArray[]){
    int i, j;
           
        //bubblesort
		for (i = 0; i < len - 1; i++){
			for (j = 0; j < len - 1 - i; j++){
		        order ( myStringsArray[j], myStringsArray[j + 1] );						
			}
		}

}


int main(){
       const char* myStringsArray[] = {"lucian", "aly", "fabio", "ioan", "andra", "paul", "alex", "maria", "loredana", "liliana"}; 
	// we need const char* here because string literals (or narrow strings) are defined by the c++ standard  to be of type const *char. In c++ string literals are first converted to the data strucutre <<string>> constant and if we would be allowed to declare the variable as char* it would mean that we can modifiy the string constant indirectly.

       
   	    sort( 10 , myStringsArray);

		
		cout << "The sorted array:" << endl;
		int t;

		for (t = 0; t < 10; t++){
		   cout << "myStringsArray[" << t << "]=" << myStringsArray[t] << endl;
		}
		

	return 0;
}
